        document.getElementById('greetButton').addEventListener('click', function () {
            alert('Bienvenue sur mon CV interactif !');
        });

        const toggleDarkModeButton = document.getElementById('toggleDarkMode');

        toggleDarkModeButton.addEventListener('click', () => {
            document.body.classList.toggle('dark-mode');
        });

        const images = document.querySelectorAll('.hover-image');

        images.forEach(image => {
            image.addEventListener('mouseover', () => {
                image.style.transform = 'scale(1.1)';
            });

            image.addEventListener('mouseout', () => {
                image.style.transform = 'scale(1)';
            });
        });