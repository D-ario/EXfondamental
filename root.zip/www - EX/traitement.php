<?php
// Connexion à la base de données Alwaysdata
$servername = "mysql-darius-parsi8.alwaysdata.net";
$username = "318458";
$password = "=CxHe7&h9D'W tK;n2H?:kd?V.;pI";
$dbname = "darius-parsi8_chap5";

$conn = new mysqli($servername, $username, $password, $dbname);

// Vérification de la connexion
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Récupérer et valider les données du formulaire
$name = htmlspecialchars(trim($_POST['name']));
$email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
$phone = htmlspecialchars(trim($_POST['phone']));
$date_of_contact = $_POST['date_of_contact'];
$message = htmlspecialchars(trim($_POST['message']));

// Vérification des erreurs de validation
if (!$email) {
    die("L'adresse e-mail n'est pas valide.");
}

if (!$date_of_contact || !preg_match("/^\d{4}-\d{2}-\d{2}$/", $date_of_contact)) {
    die("La date de contact n'est pas valide.");
}

// Insertion des données dans la base de données
$stmt = $conn->prepare("INSERT INTO contacts (name, email, phone, date_of_contact, message) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $name, $email, $phone, $date_of_contact, $message);

if ($stmt->execute()) {
    echo "Message envoyé avec succès!";
} else {
    echo "Erreur: " . $stmt->error;
}

// Fermer la connexion
$stmt->close();
$conn->close();
?>
